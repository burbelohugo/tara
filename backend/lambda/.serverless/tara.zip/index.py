from selenium import webdriver
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.common.keys import Keys
import datetime
from env import USER_EMAIL, USER_PASSWORD


PAGE_BASE_URL = "https://esjbooked.umd.edu/Web/index.php?redirect="
PAGE_NAV_URL = "https://esjbooked.umd.edu/Web/schedule.php?sd="

def handler(event, context):
    # Setup selenium webdriver
    options = Options()
    options.binary_location = '/opt/headless-chromium'
    options.add_argument('--headless')
    options.add_argument('--no-sandbox')
    options.add_argument('--single-process')
    options.add_argument('--disable-dev-shm-usage')

    driver = webdriver.Chrome('/opt/chromedriver',chrome_options=options)

    # Navigate to base page with proper date preset
    driver.get(PAGE_NAV_URL + calculateDate())

    # Enter email
    inputElement = driver.find_element_by_id("email")
    inputElement.send_keys(USER_EMAIL)

    # Enter password
    inputElement = driver.find_element_by_id("password")
    inputElement.send_keys(USER_PASSWORD)

    # Click login button
    driver.find_element_by_css_selector('#login-box > div:nth-child(5) > button').click()


    body = {
        "result": calculateDate()
    }

    driver.close()
    driver.quit()

    response = {
        "statusCode": 200,
        "body": body
    }

    return response

def calculateDate():
    currentDate = datetime.datetime.now() + datetime.timedelta(days=30)
    return currentDate.strftime("%Y-%m-%d")
